package microservices;

public class VerifyOtp
{
	public boolean verifyOtp(int otp)
	{
		if(otp==121212)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
